const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");

const app = express();
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, "public")));

// Simpan data di memori
let smartphones = [
  {
    id: 1,
    brand: "Apple",
    model: "iPhone 15",
    chipset: "A17 Pro",
    ram: 8,
    camera: 48,
    battery: 3300,
    performance_score: 950,
  },
  {
    id: 2,
    brand: "Samsung",
    model: "Galaxy S24",
    chipset: "Snapdragon 8 Gen 3",
    ram: 12,
    camera: 200,
    battery: 4000,
    performance_score: 970,
  },
];

// Ambil semua smartphone
app.get("/api/smartphones", (req, res) => res.json(smartphones));

// Tambah smartphone
app.post("/api/smartphones", (req, res) => {
  const newPhone = { id: Date.now(), ...req.body };
  smartphones.push(newPhone);
  res.json(newPhone);
});

// Ambil 1 smartphone
app.get("/api/smartphones/:id", (req, res) => {
  const phone = smartphones.find(p => p.id == req.params.id);
  if (!phone) return res.status(404).json({ error: "Not found" });
  res.json(phone);
});

app.listen(3000, () => console.log("Server running at http://localhost:3000"));
