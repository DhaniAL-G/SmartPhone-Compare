const express = require("express");
const sqlite3 = require("sqlite3").verbose();
const bodyParser = require("body-parser");
const path = require("path");

const app = express();
const db = new sqlite3.Database("./database.db");

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, "public")));

// Buat tabel jika belum ada
db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS smartphones (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      brand TEXT,
      model TEXT,
      chipset TEXT,
      ram INTEGER,
      camera INTEGER,
      battery INTEGER,
      performance_score INTEGER,
      image_url TEXT
    )
  `);
});

// --- API Routes ---

// Ambil semua smartphone
app.get("/api/smartphones", (req, res) => {
  db.all("SELECT * FROM smartphones", [], (err, rows) => {
    if (err) res.status(500).json({ error: err.message });
    else res.json(rows);
  });
});

// Tambah smartphone
app.post("/api/smartphones", (req, res) => {
  const { brand, model, chipset, ram, camera, battery, performance_score, image_url } = req.body;
  db.run(
    `INSERT INTO smartphones (brand, model, chipset, ram, camera, battery, performance_score, image_url)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [brand, model, chipset, ram, camera, battery, performance_score, image_url],
    function (err) {
      if (err) res.status(500).json({ error: err.message });
      else res.json({ id: this.lastID });
    }
  );
});

// Ambil 1 smartphone
app.get("/api/smartphones/:id", (req, res) => {
  db.get("SELECT * FROM smartphones WHERE id = ?", [req.params.id], (err, row) => {
    if (err) res.status(500).json({ error: err.message });
    else res.json(row);
  });
});

// Jalankan server
app.listen(3000, () => console.log("Server running at http://localhost:3000"));
