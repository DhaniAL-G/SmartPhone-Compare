async function loadSmartphones() {
    const res = await fetch('/api/smartphones');
    const data = await res.json();
    const list = document.getElementById('smartphone-list');
    list.innerHTML = data.map(p => `
      <div class="bg-white rounded shadow p-4">
        <h2 class="font-semibold text-lg mb-1">${p.brand} ${p.model}</h2>
        <p class="text-sm text-gray-500">${p.chipset} | ${p.ram}GB RAM</p>
        <p class="text-sm">Kamera: ${p.camera} MP | Baterai: ${p.battery} mAh</p>
        <p class="font-bold mt-2">Skor: ${p.performance_score}</p>
      </div>
    `).join('');
  }
  
  loadSmartphones();