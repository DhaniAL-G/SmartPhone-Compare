async function loadSmartphones() {
  const res = await fetch('/api/smartphones');
  const data = await res.json();
  const list = document.getElementById('smartphone-list');
  list.innerHTML = data.map(p => `
    <div class="bg-white rounded-xl shadow-md p-4 hover:shadow-lg transition">
      <h2 class="font-semibold text-lg mb-1 text-blue-600">${p.brand} ${p.model}</h2>
      <p class="text-sm text-gray-500 mb-2">${p.chipset}</p>
      <p>RAM: <strong>${p.ram} GB</strong></p>
      <p>Kamera: <strong>${p.camera} MP</strong></p>
      <p>Baterai: <strong>${p.battery} mAh</strong></p>
      <p class="font-bold text-gray-700 mt-2">Skor: ${p.performance_score}</p>
    </div>
  `).join('');
}

document.getElementById('addForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const formData = new FormData(e.target);
  const data = Object.fromEntries(formData.entries());
  data.ram = Number(data.ram);
  data.camera = Number(data.camera);
  data.battery = Number(data.battery);
  data.performance_score = Number(data.performance_score);

  const res = await fetch('/api/smartphones', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });

  if (res.ok) {
    e.target.reset();
    loadSmartphones();
  }
});

loadSmartphones();
